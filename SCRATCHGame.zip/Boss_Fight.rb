loop do
  2. times do
    use_synth :tech_saws
    play 40
    sleep 0.75
    play 35
    sleep 1
    play 36
    sleep 0.75
    play 38
  end
  use_synth :tech_saws
  play 50
  sleep 0.5
  play 50
  sleep 0.75
  sleep 0.75
  play 37
  sleep 0.75
  play 35
  2. times do
    use_synth :tech_saws
    play 40
    sleep 0.75
    play 37
    sleep 1
    play 32
    sleep 0.75
    play 38
  end
  2. times do
    use_synth :tech_saws
    play 45
    sleep 0.5
    play 36
    sleep 1
    play 40
    sleep 0.75
  end
end
